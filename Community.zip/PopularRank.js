import React from "react";
import "./Community.css";
function PopularRank() {
  return (
    <div className="popularRank">
      <div className="Rgroup">
        <div className="item">
          <img
            className="cardimg"
            src="https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
            alt="Snowy Mountains"
          />
          <div className="cardcontent">
            <h1 className="Groupname">그룹명</h1>
          </div>
        </div>
      </div>
      <div className="Rgroup">
        <div className="item">
          <img
            className="cardimg"
            src="https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
            alt="Snowy Mountains"
          />
          <div className="cardcontent">
            <h1 className="Groupname">그룹명</h1>
          </div>
        </div>
      </div>
      <div className="Rgroup">
        <div className="item">
          <img
            className="cardimg"
            src="https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
            alt="Snowy Mountains"
          />
          <div className="cardcontent">
            <h1 className="Groupname">그룹명</h1>
          </div>
        </div>
      </div>
    </div>
  );
}
export default PopularRank;
