import React from "react";

function Mypage() {
  return (
    <div>
      <h1>Main</h1>
    </div>
  );
}
export default Mypage;
